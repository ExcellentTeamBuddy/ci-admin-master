<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">  
  <title><?php //echo $pagetitle; ?> Admin Master Template</title>

  <!-- Favicon icon -->
  <!-- <link rel="icon" href="<?php echo base_url(FAVICON_ICON); ?>" type="image/svg" sizes="16x16"> -->
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/toastr/toastr.min.css">
  <!-- Confirm Alert -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/my-jquery-confirm/css/my-jquery-confirm.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/datatables-responsive/css/responsive.bootstrap4.min.css"> 
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/plugins/summernote/summernote-bs4.min.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/myStyle.css">

  <!-- Base url pass to script -->
  <script type="text/javascript">
      var baseurl = "<?php echo base_url(); ?>";
  </script>

</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand myFixedBgColorCls">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link myNavLink" data-widget="pushmenu" href="javascript:void(0)" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">      
      <li class="nav-item dropdown">
        <div class="user-panel myPt-1 d-flex" data-toggle="dropdown">
          <div class="image">
            <img src="" class="img-circle" alt="">
          </div>
          <div class="info">
            <a href="javascript:void(0)" class="d-block myNameCls">Welcome ! <b>Super Admin</b></a>
          </div>
        </div>

        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">Settings</span>
          <div class="dropdown-divider"></div>
          <a href="<?php echo base_url() ?>admin/my-profile" class="dropdown-item">
            <i class="fas fa-user mr-2"></i> My Profile            
          </a>
          <div class="dropdown-divider"></div>
          <a href="<?php echo base_url() ?>admin/my-profile/change-password" class="dropdown-item">
            <i class="fas fa-lock mr-2"></i> Change Password
          </a>          
          <div class="dropdown-divider"></div>   
          <a href="<?php echo base_url(); ?>admin/logout" class="dropdown-item">
            <i class="fas fa-sign-out-alt mr-2"></i> Logout
          </a>       
        </div>

      </li>
      <li class="nav-item">
        <!-- <a class="nav-link myNavLink" data-widget="control-sidebar" data-slide="true" href="<?php //echo base_url(); ?>admin/logout" role="button">
          <i class="fas fa-sign-out-alt"></i>
        </a> -->
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->


  <!-- Side bar -->

    <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary mySidebar-lightdark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo base_url();?>admin/dashboard" class="brand-link myBrand-link">Admin Master
     <img src="<?php //echo base_url(DISPLAY_LOGO_SMALL); ?>" alt="" class="brand-image mybrand-image-ml">
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->     

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo base_url();?>admin/dashboard" class="nav-link active myActiveCls">
              <i class="nav-icon fas fa-home"></i>
              <p>
                Dashboard
              </p>
            </a>            
          </li>
          <li class="nav-item">
            <a href="<?php echo base_url();?>admin/dashboard" class="nav-link">
              <i class="nav-icon fas fa-home"></i>
              <p>
                Dashboard 2
              </p>
            </a>            
          </li>                              
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Side bar End -->

  <!-- Page Content -->

    <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header myPageHeadingContentCls myElevation1">
      <div class="container-fluid">
        <div class="row mb-2">          
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a class="my-breadcrumb-item-link" href="<?php echo base_url(); ?>admin/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content myContent">
      <div class="container-fluid">
        <!-- Info boxes -->        
        <div class="row">
          <div class="col-12">            
            <div class="card">           
              
              <div class="card-header">
                <div class="row">
                  <div class="col-6">
                    <h3 class="m-0">Dashboard</h3>
                  </div>
                  <div class="col-6">                  
                  </div>
                </div>                
              </div>
              <!-- /.card-header -->
              
              <div class="card-body">


                <div class="row">
                  <div class="col-lg-3 col-6">
                    <!-- small card -->
                    <div class="small-box bg-info">
                      <div class="inner">
                        <h3 class="runCounter"><?php echo 0; ?></h3>
                        <p>New Orders</p>
                      </div>
                      <div class="icon">
                        <i class="fas fa-shopping-cart"></i>
                      </div>
                      <a href="#" class="small-box-footer">
                        More info <i class="fas fa-arrow-circle-right"></i>
                      </a>
                    </div>
                  </div>
                  <!-- ./col -->
                  <div class="col-lg-3 col-6">
                    <!-- small card -->
                    <div class="small-box bg-success">
                      <div class="inner">
                        <h3 class="runCounter"><?php echo 0; ?></h3>
                        <p>Total Orders</p>
                      </div>
                      <div class="icon">
                        <i class="fa fa-shopping-basket"></i>
                      </div>
                      <a href="#" class="small-box-footer">
                        More info <i class="fas fa-arrow-circle-right"></i>
                      </a>
                    </div>
                  </div>
                  <!-- ./col -->
                  <div class="col-lg-3 col-6">
                    <!-- small card -->
                    <div class="small-box bg-warning">
                      <div class="inner">
                        <h3 class="runCounter"><?php echo 0; ?></h3>
                        <p>Total Products</p>
                      </div>
                      <div class="icon">
                        <i class="fa fa-tags"></i>
                      </div>
                      <a href="#" class="small-box-footer">
                        More info <i class="fas fa-arrow-circle-right"></i>
                      </a>
                    </div>
                  </div>
                  <!-- ./col -->                  
                  <div class="col-lg-3 col-6">
                    <!-- small card -->
                    <div class="small-box bg-danger">
                      <div class="inner">
                        <h3 class="runCounter"><?php echo 0; ?></h3>
                        <p>Total Users</p>
                      </div>
                      <div class="icon">
                        <i class="fas fa-user-plus"></i>
                      </div>
                      <a href="#" class="small-box-footer">
                        More info <i class="fas fa-arrow-circle-right"></i>
                      </a>
                    </div>
                  </div>
                  <!-- ./col -->
                </div>
                <!-- /.row -->

                <!-- MAIN-ROW -->                
                <div class="row">


                </div>
                <!-- /.MAIN-ROW -->


              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->          
        </div>
        <!-- /.row -->                
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Page Content End -->


<!-- Footer -->

    <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- Toastr -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/toastr/toastr.min.js"></script>
<!-- Confirm Alert -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/my-jquery-confirm/js/my-jquery-confirm.min.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/select2/js/select2.full.min.js"></script>
<!-- General JS for All Pages Added Here -->


<!-- DataTables  & Plugins -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/bootstrap/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets/bootstrap/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url();?>assets/bootstrap/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- bs-custom-file-input -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url();?>assets/bootstrap/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Summernote -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/summernote/summernote-bs4.min.js"></script>

<!-- jquery-validation -->
<script src="<?php echo base_url();?>assets/bootstrap/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>assets/bootstrap/plugins/jquery-validation/additional-methods.min.js"></script>

<script src="<?php echo base_url();?>assets/bootstrap/plugins/chart.js/Chart.min.js"></script>
<!-- Template Js -->
<script src="<?php echo base_url();?>assets/bootstrap/dist/js/adminlte.js"></script>
<!-- Page JS Added Here -->


</body>
</html>